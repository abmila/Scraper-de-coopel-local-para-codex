import time, random, os
from datetime import datetime
from typing import List, Dict, Any, Tuple
from .browser_fetch import fetch_html_with_browser
from .settings import (
    URLS_FILE, OUTPUT_DIR, CSV_PATH, XLSX_PATH, PENDING_TXT,
    DEFAULT_TIME_BUDGET_SECONDS, MAX_LOOPS_DEFAULT,
    INITIAL_WAIT_RANGE, BETWEEN_REQUESTS,
    ROLLING_WINDOW, ALPHA_SENSITIVITY,
    EMAIL_SENDER, EMAIL_PASSWORD, EMAIL_TO, EMAIL_SUBJECT,
)
from .http_client import build_session, get_with_backoff
from .coppel_parser import parse_product_from_html, extract_input_id_from_url
from .storage import save_results
from .mailer import send_mail

COLUMNS = [
    "TIMESTAMP","INPUT_ID","URL_PDP","TITULO","SKU_COPPEL","VENDEDOR",
    "MARCA","MODELO_NUM","MODELO","PRECIO_REGULAR_NUM","PRECIO_PROMO_NUM","STATUS"
]

recent_soft_blocks: List[bool] = []

def jitter(a: float, b: float) -> float:
    return random.uniform(a, b)

def sleep_range(a: float, b: float) -> float:
    t = jitter(a, b)
    time.sleep(t)
    return t

def current_softblock_ratio() -> float:
    if not recent_soft_blocks:
        return 0.0
    return sum(1 for x in recent_soft_blocks if x) / len(recent_soft_blocks)

def planned_initial_wait() -> float:
    base = jitter(*INITIAL_WAIT_RANGE)
    ratio = current_softblock_ratio()
    return base * (1.0 + ALPHA_SENSITIVITY * ratio)

def read_urls(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f.read().splitlines()]
    return [ln for ln in lines if ln and not ln.startswith("#")]

    r = get_with_backoff(session, url, mark_softblock=saw_softblock)

    html = None
    http_code = ""
    if r and r.status_code not in (404,):
        http_code = str(r.status_code)
        html = r.text

    # Si requests falló o no trajo HTML -> fallback a navegador real
    if (not html) or (r is None):
        html2, st2 = fetch_html_with_browser(url)
        if html2:
            html = html2
            status = st2
        else:
            status = st2  # BROWSER_ERR(...)
            html = None

    if html is None:
        info = {}
        if status == "OK":
            status = "HTTP/Timeout error URL"
    else:
        info = parse_product_from_html(html) or {}
        if not info.get("TITULO"):
            # Si no parsea, al menos deja evidencia
            status = status if status != "OK" else f"PARSE_FAIL({http_code})"


    input_id = extract_input_id_from_url(url)

    initial_wait = planned_initial_wait()
    print(f"   Espera inicial: {initial_wait:.1f}s (ratio softblock: {current_softblock_ratio():.2f})", flush=True)
    time.sleep(initial_wait)

    r = get_with_backoff(session, url, mark_softblock=saw_softblock)
    if not r:
        status = "HTTP/Timeout error URL"
        info = {}
    elif r.status_code == 404:
        status = "404 URL"
        info = {}
    else:
        info = parse_product_from_html(r.text) or {}
        if not info.get("TITULO"):
            status = "Formato PDP desconocido"

    recent_soft_blocks.append(bool(saw_softblock[0]))
    if len(recent_soft_blocks) > ROLLING_WINDOW:
        recent_soft_blocks.pop(0)

    row = {
        "TIMESTAMP": ts,
        "INPUT_ID": input_id,
        "URL_PDP": url,
        "TITULO": info.get("TITULO",""),
        "SKU_COPPEL": info.get("SKU_COPPEL",""),
        "VENDEDOR": info.get("VENDEDOR",""),
        "MARCA": info.get("MARCA",""),
        "MODELO_NUM": info.get("MODELO_NUM",""),
        "MODELO": info.get("MODELO",""),
        "PRECIO_REGULAR_NUM": info.get("PRECIO_REGULAR_NUM",""),
        "PRECIO_PROMO_NUM": info.get("PRECIO_PROMO_NUM",""),
        "STATUS": status,
    }
    return row

def main():
    urls = read_urls(URLS_FILE)
    items: List[Tuple[str,str]] = [("url", u) for u in urls]
    print(f"Procesando {len(items)} URLs de COPPEL…\n")

    session = build_session()

    # “calentamos” cookies
    try:
        session.get("https://www.coppel.com/", timeout=(10, 30))
    except Exception:
        pass

    time_budget = float(os.getenv("TIME_BUDGET_SECONDS", str(DEFAULT_TIME_BUDGET_SECONDS)))
    max_loops = int(os.getenv("MAX_LOOPS", str(MAX_LOOPS_DEFAULT)))

    all_results: List[Dict[str, Any]] = []
    pending_items = items

    for loop_idx in range(1, max_loops + 1):
        if not pending_items:
            break

        print(f"\n================ LOOP {loop_idx}/{max_loops} - {len(pending_items)} URLs pendientes ================")
        loop_start = time.time()
        next_pending: List[Tuple[str,str]] = []

        for i, (_, url) in enumerate(pending_items, 1):
            if (time.time() - loop_start) >= time_budget:
                next_pending = pending_items[i-1:]
                break

            sleep_range(*BETWEEN_REQUESTS)
            row = process_url(session, url)
            all_results.append(row)
            print(f"[Loop {loop_idx}] [{i}/{len(pending_items)}] -> {row['STATUS']} | {url}")

        save_results(all_results, CSV_PATH, XLSX_PATH, OUTPUT_DIR)
        pending_items = next_pending

    if pending_items:
        with open(PENDING_TXT, "w", encoding="utf-8") as f:
            for _, u in pending_items:
                f.write(u + "\n")
        print(f"⚠️ Pendientes: {len(pending_items)} -> {PENDING_TXT}")

    send_mail(
        sender=EMAIL_SENDER,
        password=EMAIL_PASSWORD,
        recipients=EMAIL_TO,
        subject=EMAIL_SUBJECT,
        files=[CSV_PATH, XLSX_PATH],
    )

if __name__ == "__main__":
    main()
