import os
import pandas as pd
from typing import List, Dict, Any

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

def save_results(rows: List[Dict[str, Any]], csv_path: str, xlsx_path: str, output_dir: str):
    ensure_dir(output_dir)
    if not rows:
        print("⚠️ No hay resultados para guardar.")
        return

    df = pd.DataFrame(rows)
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    with pd.ExcelWriter(xlsx_path, engine="xlsxwriter") as writer:
        df.to_excel(writer, index=False, sheet_name="Datos")
        ws = writer.sheets["Datos"]
        if "URL_PDP" in df.columns:
            c = df.columns.get_loc("URL_PDP")
            for r, val in enumerate(df["URL_PDP"].fillna(""), start=1):
                if isinstance(val, str) and val.startswith("http"):
                    ws.write_url(r, c, val, string=val)

    print(f"💾 Guardados: {csv_path} y {xlsx_path}")
