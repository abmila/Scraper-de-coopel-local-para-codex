import json, re
from bs4 import BeautifulSoup
from typing import Any, Optional

def to_float_mxn(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)):
        return float(x)
    s = str(x).strip()
    s = s.replace("MXN", "").replace("$", "").replace(",", "").strip()
    m = re.search(r"(\d+(?:\.\d+)?)", s)
    return float(m.group(1)) if m else None

def extract_input_id_from_url(url: str) -> str:
    m = re.search(r"-(pm|mkp)-(\d+)", url)
    return m.group(2) if m else url.rstrip("/").split("/")[-1]

def parse_json_ld_products(soup: BeautifulSoup):
    out = []
    for tag in soup.find_all("script", attrs={"type": "application/ld+json"}):
        if not tag.string:
            continue
        try:
            data = json.loads(tag.string)
            if isinstance(data, list):
                out.extend([x for x in data if isinstance(x, dict)])
            elif isinstance(data, dict):
                out.append(data)
        except Exception:
            continue
    return out

def parse_product_from_html(html: str):
    soup = BeautifulSoup(html, "lxml")

    titulo = ""
    name_tag = soup.find("p", attrs={"data-testid": "pdp_product_name"})
    if name_tag:
        titulo = name_tag.get_text(" ", strip=True)

    if not titulo:
        bc = soup.find("li", attrs={"data-testid": "breadcrumb_1"})
        if bc:
            titulo = bc.get_text(" ", strip=True)

    if not titulo:
        t = soup.find("title")
        if t:
            titulo = t.get_text(" ", strip=True).replace("| Coppel.com", "").strip()

    sku_coppel = ""
    sku_tag = soup.find("p", attrs={"data-testid": "pdp_product_sku"})
    if sku_tag:
        txt = sku_tag.get_text(" ", strip=True)
        m = re.search(r"([0-9]{4,})", txt)
        if m:
            sku_coppel = m.group(1)

    vendedor = ""
    sold_by = soup.find("p", attrs={"data-testid": "pdp_product_sold_by"})
    if sold_by:
        sp = sold_by.find("span")
        if sp:
            vendedor = sp.get_text(" ", strip=True)

    modelo_num = ""
    modelo = ""
    marca = ""
    details = soup.find("ul", attrs={"data-testid": "pdp_about_product_details"})
    if details:
        for li in details.find_all("li"):
            txt = li.get_text(" ", strip=True)
            sp = li.find("span")
            val = sp.get_text(" ", strip=True) if sp else (txt.split(":")[-1].strip() if ":" in txt else "")
            if "Modelo #" in txt:
                modelo_num = val
            elif txt.lower().startswith("marca"):
                marca = val
            elif re.match(r"(?i)^modelo\s*:?", txt):
                modelo = val

    precio_promo = None
    precio_regular = None

    # promo desde JSON-LD Product.offers.price
    for obj in parse_json_ld_products(soup):
        if str(obj.get("@type", "")).lower() == "product":
            offers = obj.get("offers", {})
            if isinstance(offers, dict) and "price" in offers:
                precio_promo = to_float_mxn(offers.get("price"))
            break

    # regular desde sr-only
    price_details = soup.find(attrs={"data-testid": "pdp_price_details"})
    if price_details:
        sr = price_details.find("span", class_="sr-only")
        if sr:
            sr_txt = sr.get_text(" ", strip=True)
            m = re.search(r"precio\s+original\s*:\s*([0-9][0-9\.,]*)", sr_txt, flags=re.I)
            if m:
                precio_regular = to_float_mxn(m.group(1))

    return {
        "TITULO": titulo,
        "SKU_COPPEL": sku_coppel,
        "VENDEDOR": vendedor,
        "MARCA": marca,
        "MODELO_NUM": modelo_num,
        "MODELO": modelo,
        "PRECIO_REGULAR_NUM": precio_regular,
        "PRECIO_PROMO_NUM": precio_promo,
    }
