import os

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0.0.0 Safari/537.36"
)

DEFAULT_TIME_BUDGET_SECONDS = int(os.getenv("TIME_BUDGET_SECONDS", "5400"))
MAX_LOOPS_DEFAULT = int(os.getenv("MAX_LOOPS", "3"))

INITIAL_WAIT_RANGE = (6.0, 10.0)
BETWEEN_REQUESTS   = (3.5, 6.5)

MAX_RETRIES   = 2
BACKOFF_BASE  = 6.0
BACKOFF_CAP   = 180.0

ROLLING_WINDOW    = 8
ALPHA_SENSITIVITY = 1.1

CONNECT_TIMEOUT = 15
READ_TIMEOUT    = 120

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
URLS_FILE = os.getenv("URLS_FILE", os.path.join(BASE_DIR, "urls.txt"))

OUTPUT_DIR = os.getenv("OUTPUT_DIR", os.path.join(BASE_DIR, "outputs"))
CSV_PATH   = os.path.join(OUTPUT_DIR, "coppel_datos.csv")
XLSX_PATH  = os.path.join(OUTPUT_DIR, "coppel_datos.xlsx")
PENDING_TXT= os.path.join(OUTPUT_DIR, "coppel_pendientes.txt")

# Email (opcionales)
EMAIL_SENDER   = os.getenv("EMAIL_SENDER", "")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD", "")
EMAIL_TO       = os.getenv("EMAIL_TO", "")
EMAIL_SUBJECT  = os.getenv("EMAIL_SUBJECT", "Resultados scraper COPPEL (URLs)")
