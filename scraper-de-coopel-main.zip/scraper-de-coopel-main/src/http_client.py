import time, random
import requests
import socket
import urllib3.util.connection as urllib3_cn

# Fuerza IPv4 (evita cuelgues por IPv6)
urllib3_cn.allowed_gai_family = lambda: socket.AF_INET
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .settings import (
    UA, MAX_RETRIES, CONNECT_TIMEOUT, READ_TIMEOUT,
    BACKOFF_BASE, BACKOFF_CAP
)



def jitter(a: float, b: float) -> float:
    return random.uniform(a, b)

def build_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": UA,
        "Accept-Language": "es-MX,es;q=0.9,en;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Referer": "https://www.coppel.com/",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
    })

    retry = Retry(
        total=MAX_RETRIES,
        connect=MAX_RETRIES,
        read=0,
        backoff_factor=0.5,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["GET", "HEAD"],
        raise_on_status=False,
        respect_retry_after_header=True,
    )
    s.mount("http://", HTTPAdapter(max_retries=retry))
    s.mount("https://", HTTPAdapter(max_retries=retry))
    return s

def get_with_backoff(session: requests.Session, url: str, mark_softblock: list | None = None):
    last_status = None
    for i in range(MAX_RETRIES):
        try:
            r = session.get(url, allow_redirects=True, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
            last_status = r.status_code

            if r.status_code in (200, 404):
                return r

            if r.status_code in (429, 403):
                if mark_softblock is not None:
                    mark_softblock[0] = True
                wait = min(BACKOFF_BASE * (2 ** i), BACKOFF_CAP) + jitter(2.0, 6.0)
                print(f"   HTTP {r.status_code} -> backoff {wait:.1f}s ({i+1}/{MAX_RETRIES})")
                time.sleep(wait)
                continue

            time.sleep(2.0 + i * 0.75)

        except requests.exceptions.ReadTimeout:
            if mark_softblock is not None:
                mark_softblock[0] = True
            wait = min(BACKOFF_BASE * (2 ** i), BACKOFF_CAP) + jitter(3.0, 8.0)
            print(f"   ⏱️ ReadTimeout -> backoff {wait:.1f}s ({i+1}/{MAX_RETRIES})")
            time.sleep(wait)

        except requests.RequestException as e:
            wait = 2.5 + i * 1.25
            print(f"   Error red: {type(e).__name__} -> {wait:.1f}s ({i+1}/{MAX_RETRIES})")
            time.sleep(wait)

    print(f"   Error red: {type(e).__name__}: {repr(e)} -> {wait:.1f}s ({i+1}/{MAX_RETRIES})", flush=True)

    return None
