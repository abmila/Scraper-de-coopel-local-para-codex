from __future__ import annotations
from typing import Optional, Tuple
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

def fetch_html_with_browser(url: str, timeout_ms: int = 60000) -> Tuple[Optional[str], str]:
    """
    Devuelve (html, status). status es texto para logs.
    """
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ])
            context = browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/126.0.0.0 Safari/537.36"
                ),
                locale="es-MX",
            )
            page = context.new_page()
            page.set_default_navigation_timeout(timeout_ms)

            resp = page.goto(url, wait_until="domcontentloaded")
            # Espera extra por contenido dinámico (sin colgarse)
            try:
                page.wait_for_load_state("networkidle", timeout=15000)
            except PWTimeout:
                pass

            html = page.content()
            code = resp.status if resp is not None else 0

            context.close()
            browser.close()

            return html, f"BROWSER_OK({code})"
    except Exception as e:
        return None, f"BROWSER_ERR({type(e).__name__}: {e})"
