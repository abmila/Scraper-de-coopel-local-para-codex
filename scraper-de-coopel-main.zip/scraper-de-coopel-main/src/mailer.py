import os, ssl, smtplib
from email.message import EmailMessage
from typing import List

def send_mail(sender: str, password: str, recipients: str, subject: str, files: List[str]):
    if not sender or not password or not recipients:
        print("ℹ️ Email no configurado (faltan env vars). No se envía correo.")
        return

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = recipients
    msg.set_content("Hola,\n\nTe mando los archivos generados por el scraper de COPPEL.\n\nSaludos.")

    for fn in files:
        if not os.path.exists(fn):
            print(f"⚠️ No existe: {fn}")
            continue
        with open(fn, "rb") as f:
            data = f.read()
        msg.add_attachment(data, maintype="application", subtype="octet-stream", filename=os.path.basename(fn))
        print(f"✅ Adjuntado: {fn}")

    print("📨 Enviando correo…")
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(sender, password)
        server.send_message(msg)
    print("✅ Correo enviado.")
